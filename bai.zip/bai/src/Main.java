import java.io.IOException;

class Node {
    private Node left;
    private Node right;
    private Node parent;
    private String name = "";
    private int value;
    public Node(int v){
        value = v;
    }
    public void add_left(int v){
        left = new Node(v);
        left.parent = this;
        left.name = name + "0";
    }
    public void add_right(int v){
        right = new Node(v);
        right.parent = this;
        right.name = name + "1";
    }
    public void delete_left(){
        left = null;
    }
    public void delete_right(){
        right = null;
    }
    public Node step_left(){
        if(left != null) return left;
        return this;
    }
    public Node step_right(){
        if(right != null) return right;
        return this;
    }
    public Node step_up(){
        return parent;
    }
    public Boolean find_name(String s){
        int cnt = 0;
        for(int i = 0; i < Math.min(s.length(), name.length()); i++){
            if(s.codePointAt(i) == name.codePointAt(i)) cnt++;
            else break;
        }
        Node node = this;
        for(int i = 0; i < s.length() - cnt; i++){
            if(node.parent != null) node = node.parent;
            else return false;
        }
        while(cnt < s.length()){
            if(s.codePointAt(cnt) == '0'){
                if(node.left != null) node = node.left;
                else return false;
            }
            else{
                if(node.right != null) node = node.right;
                else return false;
            }
            cnt++;
        }
        return true;
    }
    public Boolean find_value(int v){
        if(this.value == v) return true;
        if(v < this.value && left != null) return left.find_value(v);
        if(v > this.value && right != null) return right.find_value(v);
        return false;
    }
    public void write_value(){
        if (left != null){
            left.write_value();
        }
        System.out.println(this.value + " ");
        if (right != null){
            right.write_value();
        }
    }
}

public class Main {
    public static void main(String[] args) throws IOException {
        Node a = new Node(100);
        a.add_left(50);
        a.add_right(150);
        a = a.step_right();
        a.add_left(120);
        a.add_right(300);
        a.delete_right();
        a = a.step_up();
        a.write_value();
    }
}
